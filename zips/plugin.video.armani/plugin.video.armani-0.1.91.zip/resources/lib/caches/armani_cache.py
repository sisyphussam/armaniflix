from xbmcgui import DialogProgress, Dialog
from xbmcvfs import translatePath, delete
import requests
import csv
import sqlite3
import json
from operator import itemgetter
import re
import unicodedata

DB = translatePath('special://profile/addon_data/plugin.video.armani/databases/armani.db')

TMDB_TOKEN = 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI1NTFiYWEzYjU4YTM0MmM0NGUwNmM5OGE1NTYwODA4ZiIsInN1YiI6IjYzZWM3ODAz' \
             'MWYzZTYwMDA3ZmI1ZTQxYSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.YFH_FtAhTLPZcWLKUYvofUKiPs' \
             'fiHFpN9pZKI-M9O7o'
TMDB_HEADERS = {'Authorization': 'Bearer %s' % TMDB_TOKEN, 'accept': 'application/json'}
TMDB_BASE_URL = 'https://api.themoviedb.org/3/'
TMDB_LANGUAGE = 'en-US'

IMDB_HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0",
                "Accept-Encoding": "gzip, deflate",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "DNT": "1",
                "Connection": "close",
                "Upgrade-Insecure-Requests": "1"}

IMDB_CSV_URL = 'http://www.imdb.com/list/%s/export?ref_=ttls_exp'

IMDB_LISTS = {
    'TV Shows': 'ls525573312',
    'Movies / 1920s': 'ls525727850',
    'Movies / 1930s': 'ls525721034',
    'Movies / 1940s': 'ls525721336',
    'Movies / 1950s': 'ls525723501',
    'Movies / 1960s': 'ls525723322',
    'Movies / 1970s': 'ls525723868',
    'Movies / 1980s': 'ls525726798',
    'Movies / 1990s': 'ls525726451',
    'Movies / 2000s': 'ls525722605',
    'Movies / 2010s': 'ls525749272',
    'Movies / 2020s': 'ls525780934',
}

GENRES = {
    'act': 'Action',
    'adu': 'Adult',
    'adv': 'Adventure',
    'ani': 'Animation',
    'asi': 'Asian',
    'bio': 'Biography',
    'com': 'Comedy',
    'cri': 'Crime',
    'doc': 'Documentary',
    'dra': 'Drama',
    'dys': 'Dystopian',
    'fam': 'Family',
    'fan': 'Fantasy',
    'fil': 'Film-Noir',
    'gam': 'Game Show',
    'hei': 'Heist Film',
    'his': 'History',
    'hor': 'Horror',
    'int': 'International',
    'mar': 'Martial Arts',
    'muc': 'Music',
    'mus': 'Musical',
    'mys': 'Mystery',
    'new': 'News',
    'rea': 'Reality TV',
    'rom': 'Romance',
    'sam': 'Samurai',
    'sch': 'School',
    'sci': 'Science Fiction',
    'sho': 'Short',
    'sil': 'Silent Film',
    'spo': 'Sport',
    'sup': 'Superhero',
    'sur': 'Surrealism',
    'tal': 'Talk Show',
    'thr': 'Thriller',
    'war': 'War',
    'wes': 'Western',
    'zom': 'Zombies'
}

IMDB_GENRES = {
    'Action': 'act', 'Adult': 'adu', 'Adventure': 'adv', 'Animation': 'ani', 'Biography': 'bio', 'Comedy': 'com',
    'Crime': 'cri', 'Documentary': 'doc', 'Drama': 'dra', 'Family': 'fam', 'Fantasy': 'fan', 'Film-Noir': 'fil',
    'Game-Show': 'gam', 'History': 'his', 'Horror': 'hor', 'Musical': 'mus', 'Music': 'muc', 'Mystery': 'mys',
    'News': 'new', 'Reality-TV': 'rea', 'Romance': 'rom', 'Sci-Fi': 'sci', 'Short': 'sho', 'Sport': 'spo',
    'Talk-Show': 'tal', 'Thriller': 'thr', 'War': 'war', 'Western': 'wes'
}

KEYWORD_GENRES = {
    'movie': {
        4565: 'dys', 4458: 'dys',
        10051: 'hei', 155508: 'hei', 191845: 'hei', 40903: 'hei', 159413: 'hei', 177438: 'hei',
        779: 'mar', 780: 'mar',
        1462: 'sam',
        10873: 'sch', 6270: 'sch', 3616: 'sch',
        154802: 'sil',
        9715: 'sup', 155030: 'sup', 180547: 'sup',
        9887: 'sur', 3307: 'sur',
        12377: 'zom', 186565: 'zom', 313999: 'zom'
    },
    'tv': {
        10873: 'sch', 6270: 'sch', 3616: 'sch',
        9715: 'sup', 155030: 'sup', 180547: 'sup',
        9887: 'sur', 3307: 'sur',
        12377: 'zom', 186565: 'zom', 313999: 'zom'
    }
}

NUM_EXAMPLES = 10


def get_tmdb_data(session: requests.Session, url):
    """Fetch TMDb data from the specified URL.

    Example:
        get_tmdb_data('movie/6969/credits?language=en-US')

    Args:
        session: the session object (requests)
        url: the part of the TMDb URL after 'https://api.themoviedb.org/3/'

    Returns:
        JSON of TMDb data if successfully retrieved, empty dict otherwise
    """
    if not url.startswith(TMDB_BASE_URL):
        url = TMDB_BASE_URL + url
    response = session.get(url, headers=TMDB_HEADERS)
    if response.status_code != 200:
        return {}
    return response.json()


def _search_string(s):
    s = unicodedata.normalize('NFD', s)
    s = s.encode('ascii', 'ignore')
    s = s.decode("utf-8")
    s = re.sub(r'[^A-Za-z\d]+', '', s)
    return s


class ArmaniCache:
    """ A database containing all movies and TV shows listed in GitHub CSV files. """

    def __init__(self):
        self.conn = sqlite3.connect(DB)
        self.cursor = self.conn.cursor()
        self.language = 'en-US'
        try:
            self.cursor.execute('SELECT imdb_id, hash FROM media_hashes')
            self.hashes = {r[0]: r[1] for r in self.cursor.fetchall()}
        except:
            self.hashes = {}
            self.clean_database()

        try:
            self.menu = self.__load_menu()
        except:
            self.clean_database()
            self.menu = self.__load_menu()

    def clean_database(self):
        """ Re-creates the database and updates the contents. """

        # Delete the old database (tables may no longer exist)
        self.conn.close()
        delete(DB)
        self.conn = sqlite3.connect(DB)
        self.cursor = self.conn.cursor()

        self.cursor.executescript("""
            CREATE TABLE media (
                imdb_id TEXT NOT NULL UNIQUE,
                db_type TEXT NOT NULL,
                tmdb_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                sort_title TEXT,
                release_date TEXT,
                starting_letter TEXT,
                decade INTEGER,
                imdb_rating REAL,
                imdb_votes INTEGER,
                UNIQUE(db_type, tmdb_id)
            );

            CREATE TABLE media_genres (
                imdb_id TEXT NOT NULL,
                genre_id TEXT NOT NULL,
                UNIQUE(imdb_id, genre_id)
            );

            CREATE TABLE media_search (
                imdb_id TEXT NOT NULL,
                search_string TEXT NOT NULL,
                UNIQUE(imdb_id, search_string)
            );

            CREATE TABLE IF NOT EXISTS media_hashes (
                imdb_id TEXT NOT NULL,
                hash TEXT NOT NULL
            );
        """)
        self.conn.commit()

        if self.hashes:
            self.cursor.executemany('INSERT INTO media_hashes VALUES(?, ?)', [(k, v) for k, v in self.hashes.items()])
            self.conn.commit()

    def get_title(self, main_key, sub_key):
        """
        Returns the title/name of the genre, decade, or starting letter.

        Example:
            get_title('movies_genres', 'com')

        Args:
            main_key: movies_genres, tvshows_decades, movies_alpha, etc.
            sub_key: act, 1960, A, etc.

        Returns:
            The title associated with the main and sub key.
        """
        content_type, category = main_key.split('_')
        return self.menu[content_type][category][sub_key]['title']

    def get_list(self, main_key):
        """
        Returns a dict containing the title, summary and count associated with the specified key
        (used for menu InfoLabels).

        Example:
            get_list('tvshows_decades')

        Args:
            main_key: movies_genres, tvshows_decades, movies_alpha, etc.

        Returns:
            A dict containing key, title, summary, and count. For example:

            {'key': '1980', 'title': '1980 - 1989', 'summary': EXAMPLE_LIST, 'count': NUM_RESULTS}
        """
        content_type, category = main_key.split('_')
        m = self.menu[content_type][category]
        return {k: {'key': k, 'title': v['title'], 'summary': v['examples'], 'count': v['count']} for k, v in m.items()}

    def get_content(self, main_key, sub_key):
        """
        Returns a list of (tmdb_id, db_type) tuples associated with the specified key and id
        (used for movie/TV listings).

        Example:
            get_content('movies_alpha', '#')

        Args:
            main_key: movies_genres, tvshows_decades, movies_alpha, etc.
            sub_key: act, 1960, A, etc.

        Returns:
            All associated (tmdb_id, db_type) tuples (sorted by sort_title)
        """
        content_type, category = main_key.split('_')
        m = self.menu[content_type][category][str(sub_key)]
        return m['items']

    def search(self, query):
        """
        Search the media_search table for the specified query.

        Args:
            query: a string (title or person's name) to search for

        Returns:
            A list of all matching (tmdb_id, db_type) tuples.
        """
        query = '%' + _search_string(query) + '%'
        self.cursor.execute(f"""
            SELECT tmdb_id, db_type
            FROM media LEFT JOIN media_search ON media.imdb_id = media_search.imdb_id
            WHERE search_string LIKE ?
            ORDER BY sort_title, release_date
        """, [query])
        results = [(str(r[0]), r[1]) for r in self.cursor.fetchall()]
        return "" if not results else json.dumps({'items': results})

    def fetch_hash(self, imdb_id):
        """
        Return the saved hash associated with the specified IMDb id if it exists.
        (A saved hash will have a higher priority when sources are generated.)

        Args:
            imdb_id: the IMDb id (e.g., tt0095016)

        Returns:
            The hash string if it exists, empty string otherwise
        """
        return "" if imdb_id not in self.hashes else self.hashes[imdb_id]

    def save_hash(self, imdb_id, source):
        """
        Store a hash from a source in the database (one hash per IMDb ID).
        (A saved hash will have a higher priority when sources are generated.)

        Args:
            imdb_id: the IMDb id (e.g., tt0095016)
            source: a dict containing a 'hash' value
        """
        self.cursor.execute('INSERT OR REPLACE INTO media_hashes VALUES(?, ?)', (imdb_id, source['hash']))
        self.conn.commit()
        self.hashes[imdb_id] = source['hash']

    def download_update(self):
        """
        1. Download CSV files from IMDB lists
        2. Remove database entries not found in CSV files
        3. Add new entries to the database
        """

        ans = Dialog().yesno(
            'ArmaniFlix: Update Database',
            'Update to add new movies and TV shows; reload to clear the database and add all movies and TV shows.',
            'Update', 'Reload (slow)')
        if ans:
            self.clean_database()

        prog = DialogProgress()
        prog.create('ArmaniFlix', 'Updating database')

        self.cursor.execute('SELECT imdb_id, db_type FROM media')
        existing_imdb = {r[0]: r[1] for r in self.cursor.fetchall()}
        insert_imdb = []
        i = 0

        # Get new entries from IMDb CSV data
        with requests.Session() as s:
            for list_name, list_id in IMDB_LISTS.items():
                prog.update(int(100 * i / len(IMDB_LISTS)), 'Fetching list: %s' % list_name)
                i += 1

                download = s.get(IMDB_CSV_URL % list_id, headers=IMDB_HEADERS)
                decoded_content = download.content.decode('utf-8')
                csv_reader = csv.reader(decoded_content.splitlines(), delimiter=',')
                line_count = -1
                for row in csv_reader:
                    line_count += 1
                    if line_count == 0:
                        continue
                    if len(row) < 2:
                        break
                    imdb_id = row[1]
                    if row[4].strip().lower() == 'set':
                        db_type = 'movie_set'
                    elif row[7] in ('movie', 'tvMovie'):
                        db_type = 'movie'
                    else:
                        db_type = 'tvshow'

                    if imdb_id in existing_imdb and existing_imdb[imdb_id] == db_type:
                        existing_imdb.pop(imdb_id)
                        continue
                    imdb_rating = float(row[8] or 0)
                    imdb_votes = int(row[12] or 0)
                    genres = [IMDB_GENRES[g] for g in row[11].split(', ')]
                    insert_imdb.append({
                        'imdb_id': imdb_id,
                        'db_type': db_type,
                        'imdb_rating': imdb_rating,
                        'imdb_votes': imdb_votes,
                        'genres': genres
                    })

        # Check if database is already up to date
        if not existing_imdb and not insert_imdb:
            Dialog().ok('ArmaniFlix', 'The database is already up to date')
            return

        # Delete entries not found in IMDb lists
        if existing_imdb:
            delete_values = [(imdb_id,) for imdb_id in existing_imdb]
            self.cursor.executemany('DELETE FROM media WHERE imdb_id = ?', delete_values)
            self.cursor.executemany('DELETE FROM media_genres WHERE imdb_id = ?', delete_values)
            self.cursor.executemany('DELETE FROM media_search WHERE imdb_id = ?', delete_values)
            self.conn.commit()

        i = 0
        if insert_imdb:
            with requests.Session() as s:
                for imdb in insert_imdb:
                    if i % 4 == 0:
                        prog.update(int(100 * i / len(insert_imdb)), 'Adding movies and TV shows to the database.')
                    data = get_tmdb_data(s, 'find/%s?external_source=imdb_id' % imdb['imdb_id'])
                    if not data:
                        continue
                    if imdb['db_type'] in ('movie', 'movie_set') and not data['movie_results']:
                        continue
                    if imdb['db_type'] == 'tvshow' and not data['tv_results']:
                        continue
                    if imdb['db_type'] == 'movie':
                        tmdb = self.__get_media_data(s, 'movie', data['movie_results'][0]['id'])
                    elif imdb['db_type'] == 'tvshow':
                        tmdb = self.__get_media_data(s, 'tv', data['tv_results'][0]['id'])
                    else:
                        tmdb = self.__get_collection_data(s, data['movie_results'][0]['id'])
                    if not tmdb:
                        continue

                    # Sort title initially is the normalized title (accents replaced)
                    sort_title = unicodedata.normalize('NFD', tmdb['title'])
                    sort_title = sort_title.encode('ascii', 'ignore')
                    sort_title = sort_title.decode("utf-8")
                    # After the following steps, "!!The ##Weird Collection" becomes "Weird"
                    sort_title = re.sub(r' Collection$', '', sort_title, flags=re.IGNORECASE)
                    sort_title = re.sub(r'^[^A-Za-z\d]*', '', sort_title)
                    sort_title = re.sub(r'^(A |An |The )', '', sort_title, flags=re.IGNORECASE)
                    sort_title = re.sub(r'^[^A-Za-z\d]*', '', sort_title)
                    # A blank sort_title will result if the title is bizarre (e.g., all non-ascii characters)
                    if not sort_title:
                        sort_title = tmdb['title']

                    genres = list(dict.fromkeys(imdb['genres'] + tmdb['extra_genres']))
                    media_vals = (imdb['imdb_id'], imdb['db_type'], tmdb['tmdb_id'], tmdb['title'], sort_title,
                                  tmdb['release_date'],
                                  sort_title[0].upper() if sort_title[0].isalpha() else '#',
                                  int(int(tmdb['release_date'][:4]) / 10) * 10,
                                  imdb['imdb_rating'], imdb['imdb_votes'])
                    genre_vals = [(imdb['imdb_id'], g) for g in genres]
                    search_vals = [(imdb['imdb_id'], w) for w in tmdb['search_words']]
                    try:
                        self.cursor.execute('INSERT INTO media VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', media_vals)
                    except sqlite3.IntegrityError:
                        continue
                    self.cursor.executemany('INSERT INTO media_genres VALUES(?, ?)', genre_vals)
                    self.cursor.executemany('INSERT INTO media_search VALUES(?, ?)', search_vals)
                    i += 1
                    if prog.iscanceled():
                        break
            self.conn.commit()

        self.menu = self.__load_menu()
        prog.close()
        Dialog().ok('ArmaniFlix Updated', 'Added %d new entries (%d removed)' % (i, len(existing_imdb)))

    def __get_collection_data(self, session: requests.Session, first_tmdb_id):
        details = get_tmdb_data(session, 'movie/%d?language=%s' % (first_tmdb_id, self.language))
        if not details or not details['belongs_to_collection']:
            return {}
        collection_id = details['belongs_to_collection']['id']
        collection_details = get_tmdb_data(session, 'collection/%d?language=%s' % (collection_id, self.language))
        title = collection_details['name']
        release_date, search_words, extra_genres = "", [], []
        for p in collection_details['parts']:
            if not p.get('release_date'):
                continue
            m_data = self.__get_media_data(session, 'movie', p['id'])
            if p['id'] == first_tmdb_id:
                release_date = m_data['release_date']
            search_words.extend(m_data['search_words'])
            extra_genres.extend(m_data['extra_genres'])
        search_words = list(dict.fromkeys(search_words))
        extra_genres = list(dict.fromkeys(extra_genres))

        return {
            'tmdb_id': collection_id, 'title': title, 'release_date': release_date,
            'search_words': search_words, 'extra_genres': extra_genres
        }

    def __get_media_data(self, session: requests.Session, media_type, tmdb_id):
        details = get_tmdb_data(session, '%s/%d?language=%s' % (media_type, tmdb_id, self.language))
        all_credits = get_tmdb_data(session, '%s/%d/credits?language=%s' % (media_type, tmdb_id, self.language))
        keywords = get_tmdb_data(session, '%s/%d/keywords' % (media_type, tmdb_id))

        if not details:
            return {}

        original_language = details['original_language']
        if media_type == 'movie':
            title = details['title']
            release_date = details['release_date']
            keywords = keywords['keywords']
        else:
            title = details['name']
            release_date = details['first_air_date']
            keywords = keywords['results']

        cast, directors, writers = [], [], []

        if all_credits.get('cast', []):
            cast = sorted(all_credits['cast'], key=itemgetter('order'))[0:6]

        # Get the two most popular directors and the two most popular writers
        if all_credits.get('crew', []):
            crew = sorted(all_credits['crew'], key=itemgetter('popularity'), reverse=True)
            directors = [c for c in crew if c['job'] == 'Director'][0:2]
            writers = [c for c in crew if c['department'] == 'Writing'][0:2]

        extra_genres = [KEYWORD_GENRES[media_type][w['id']] for w in keywords if w['id'] in KEYWORD_GENRES[media_type]]
        if original_language in ('vi', 'id', 'ja', 'ko', 'th', 'cn', 'zh'):
            extra_genres.append('asi')
        elif original_language != 'en':
            extra_genres.append('int')

        search_words = [title]
        search_words += [c['name'] for c in cast] + [c['name'] for c in directors] + [c['name'] for c in writers]
        search_words = [_search_string(w) for w in search_words]
        search_words = list(dict.fromkeys(search_words))

        return {
            'tmdb_id': tmdb_id, 'title': title, 'release_date': release_date,
            'search_words': search_words, 'extra_genres': extra_genres
        }

    def __load_menu(self):
        # Returns the menu dictionary to be stored in memory
        def get_json(sql_extra, col_name, example_order='imdb_rating DESC'):
            # Get all found column values (e.g., col_name='decade' -> 1950, 1970, 2000)
            self.cursor.execute(f'SELECT DISTINCT({col_name}) FROM media {sql_extra} ORDER BY {col_name}')
            found_cols = [c[0] for c in self.cursor.fetchall()]

            data = {}
            for col_value in found_cols:
                # Get content (all items)
                self.cursor.execute(f'SELECT tmdb_id, db_type FROM media {sql_extra} AND {col_name} = ? '
                                    f'ORDER BY sort_title, release_date', [col_value])
                all_items = [(r[0], r[1]) for r in self.cursor.fetchall()]

                # Set the title
                if col_name == 'decade':
                    title = f'{col_value} - {col_value + 9}'
                elif col_name == 'starting_letter':
                    title = col_value
                else:
                    title = GENRES[col_value]

                # Get examples
                self.cursor.execute(f'SELECT title FROM media {sql_extra} AND {col_name} = ? '
                                    f'ORDER BY {example_order} LIMIT {NUM_EXAMPLES}', [col_value])
                examples = '[B]Examples:[/B][CR]' + '[CR]'.join([c[0] for c in self.cursor.fetchall()])

                data[str(col_value)] = {'title': title, 'count': len(all_items), 'examples': examples,
                                        'items': all_items}

            return data

        db_where_movie = "WHERE db_type IN ('movie', 'movie_set')"
        db_where_tv = "WHERE db_type = 'tvshow'"
        genre_sql = "LEFT JOIN media_genres ON media.imdb_id = media_genres.imdb_id "
        return {
            'movies': {
                'alpha': get_json(db_where_movie, 'starting_letter'),
                'decades': get_json(db_where_movie, 'decade'),
                'genres': get_json(genre_sql + db_where_movie, 'genre_id', 'RANDOM()')
            },
            'tvshows': {
                'alpha': get_json(db_where_tv, 'starting_letter'),
                'decades': get_json(db_where_tv, 'decade'),
                'genres': get_json(genre_sql + db_where_tv, 'genre_id', 'RANDOM()'),
            }
        }


armani = ArmaniCache()
