# -*- coding: utf-8 -*-
from apis.armani_api import armani_list
from modules import kodi_utils
from modules.kodi_utils import logger

sys, build_url, make_listitem, set_view_mode = kodi_utils.sys, kodi_utils.build_url, kodi_utils.make_listitem, kodi_utils.set_view_mode
add_items, set_content, external_browse, end_directory = kodi_utils.add_items, kodi_utils.set_content, kodi_utils.external_browse, kodi_utils.end_directory
kodi_version = kodi_utils.kodi_version

def armani_build_list(action):
	def _builder():
		for item in user_lists:
			try:
				cm = []
				title = item['title']
				url = build_url({'mode': mode, 'action': action, 'value': item['key']})
				listitem = make_listitem()
				listitem.setLabel(title)
				
				if kodi_version >= 20:
					info_tag = listitem.getVideoInfoTag()
					info_tag.setMediaType('video')
					info_tag.setPlot(item['summary'])
				else: listitem.setInfo('video', {'plot': item['summary']})
				listitem.setProperty('fen.context_main_menu_params', build_url({'mode': 'menu_editor.edit_menu_external', 'name': title, 'iconImage': 'imdb'}))
				listitem.setProperty('armani_count', str(item['count']))
				
				options_params = build_url({'mode': 'options_menu_choice', 'content': 'armani_menu', 'key': action, 'sub_key': item['key'],
					'title': item['title'], 'summary': item['summary'], 'count': item['count'], 'is_widget': 'true'})
				listitem.setProperty('fen.options_params', options_params)
				
				yield (url, listitem, True)
			except: pass
	handle = int(sys.argv[1])
	user_lists = armani_list(action)
	
	mode = 'build_armani_list'
	add_items(handle, list(_builder()))
	set_content(handle, 'files')
	end_directory(handle)
	if not external_browse(): set_view_mode('view.main')